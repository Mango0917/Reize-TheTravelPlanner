/** Automatically generated file. DO NOT MODIFY */
package com.integratedideas.speechandaudio;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}